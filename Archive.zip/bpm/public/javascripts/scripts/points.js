'use strict';
$(document).ready(function() {
    var lnameState = true;
    var fnameState = true;
    var dpointsState = true; //true is high, false is low
    var spointsState = true;
    var dmatchesState = true;
    var smatchesState = true;
    var cityState = true;
    var stateState = true;
    var fullPlayersList = players;
    var editedPlayersList = players;


    $('table').stickyTableHeaders();
    $(document).foundation();
    $('#results').html(fullPlayersList.length);

    $('#fname').click(function(e) {
        e.preventDefault();

        editedPlayersList.sort(function(a, b) {
            if (fnameState !== true) {
                return b.firstName.toUpperCase().localeCompare(a.firstName.toUpperCase());
            } else {
                return a.firstName.toUpperCase().localeCompare(b.firstName.toUpperCase());

            }
        });

        fnameState = !fnameState;

        return updateHtml(editedPlayersList);
    });

    $('#lname').click(function(e) {
        e.preventDefault();
        fullPlayersList.sort(function(a, b) {
            if (lnameState !== true) {
                return b.lastName.toUpperCase().localeCompare(a.lastName.toUpperCase());
            } else {
                return a.lastName.toUpperCase().localeCompare(b.lastName.toUpperCase());

            }
        });
        lnameState = !lnameState;
        updateHtml(fullPlayersList);
    });

    $('#city').click(function(e) {
        e.preventDefault();
        fullPlayersList.sort(function(a, b) {
            if (cityState !== true) {
                return b.city.toUpperCase().localeCompare(a.city.toUpperCase());
            } else {
                return a.city.toUpperCase().localeCompare(b.city.toUpperCase());

            }
        });
        cityState = !cityState;
        updateHtml(fullPlayersList);
    });
    
    $('#state').click(function(e) {
        e.preventDefault();
        fullPlayersList.sort(function(a, b) {
            if (stateState !== true) {
                return b.state.toUpperCase().localeCompare(a.state.toUpperCase());
            } else {
                return a.state.toUpperCase().localeCompare(b.state.toUpperCase());

            }
        });
        stateState = !stateState;
        updateHtml(fullPlayersList);
    });

    $('#dpoints').click(function(e) {
        e.preventDefault();

        editedPlayersList.sort(function(a, b) {
            if (dpointsState !== true) {
                return a.doublesPoints - b.doublesPoints;

            } else {
                return b.doublesPoints - a.doublesPoints;

            }
        });
        dpointsState = !dpointsState;

        return updateHtml(editedPlayersList);
    });

    $('#spoints').click(function(e) {
        e.preventDefault();
        fullPlayersList.sort(function(a, b) {
            if (spointsState !== true) {
                return a.singlesPoints - b.singlesPoints;

            } else {
                return b.singlesPoints - a.singlesPoints;

            }
        });
        spointsState = !spointsState;
        updateHtml(fullPlayersList);
    });

    $('#dmatches').click(function(e) {
        e.preventDefault();
        fullPlayersList.sort(function(a, b) {
            if (dmatchesState !== true) {
                return a.doublesMatches - b.doublesMatches;

            } else {
                return b.doublesMatches - a.doublesMatches;

            }
        });
        dmatchesState = !dmatchesState;

        return updateHtml(fullPlayersList);
    });



    $('#smatches').click(function(e) {
        e.preventDefault();
        fullPlayersList.sort(function(a, b) {
            if (smatchesState !== true) {
                return a.singlesMatches - b.singlesMatches;

            } else {
                return b.singlesMatches - a.singlesMatches;

            }
        });
        smatchesState = !smatchesState;
        updateHtml(fullPlayersList);
    });


    $('#submit').click(function(e) {
        e.preventDefault();
        var playerPoints = $('#select-player').val();
        var limit = $('#limit').val();
        var difference = limit - playerPoints;
        editedPlayersList = [];


        for (var x = 0; x < fullPlayersList.length; x++) {
            if (difference >= fullPlayersList[x].doublesPoints) {
                editedPlayersList.push(fullPlayersList[x]);
            }
        }
        $('#results').html(editedPlayersList.length);

        editedPlayersList.sort(function(a, b) {
            return b.doublesPoints - a.doublesPoints;
        });
        dpointsState = false;

        return updateHtml(editedPlayersList);
    });
});



function updateHtml(fullPlayersListArr) {
    $('#rankings tbody').html('');
    var cachedLength = fullPlayersListArr.length;

    for (var x = 0; x < cachedLength; x++) {
        var visibilityClass = 'show-for-large';
        if (fullPlayersListArr[x].doublesMatches) {
            $('#rankings tbody').append('<tr><td class="' + visibilityClass + '">' + fullPlayersListArr[x].code + '</td><td>' + fullPlayersListArr[x].lastName + '</td><td>' + fullPlayersListArr[x].firstName + '</td><td class="' + visibilityClass + '">' + fullPlayersListArr[x].city + '</td><td  class="' + visibilityClass + '">' + fullPlayersListArr[x].state + '</td><td>' + fullPlayersListArr[x].doublesPoints + '</td><td class="' + visibilityClass + '">' + fullPlayersListArr[x].doublesMatches + '</td><td>' + fullPlayersListArr[x].singlesPoints + '</td><td class="' + visibilityClass + '">' + fullPlayersListArr[x].singlesMatches + '</td></tr>');
        } else {
            $('#rankings tbody').append('<tr><td class="' + visibilityClass + '">' + fullPlayersListArr[x].code + '</td><td>' + fullPlayersListArr[x].lastName + '</td><td>' + fullPlayersListArr[x].firstName + '</td><td class="' + visibilityClass + '">' + fullPlayersListArr[x].city + '</td><td  class="' + visibilityClass + '">' + fullPlayersListArr[x].state + '</td><td>' + fullPlayersListArr[x].doublesPoints + '</td><td>' + fullPlayersListArr[x].singlesPoints + '</td></tr>');
        }

    }
}
