'use strict';

var express = require('express');
var router = express.Router();
var http = require('http');

/* GET home page. */
router.get('/', function(req, res, next) {

    scrape(function(tableData) {
        res.render('index', { title: 'Bonzini Points Machine', headlines: tableData.tableHeader, players: tableData.tableData });
    });

});

router.get('/sort-doubles-point/:direction?', function(req, res) {

    scrape(function(tableData) {
    	var sortedData = tableData.tableData;
    	res.send({players: sortedData});

    });
});

router.get('/sort-doubles-points:direction', function(req, res) {
    scrape(function(tableData) {

    });
});

router.get('/sort-doubles-points:direction', function(req, res) {
    scrape(function(tableData) {

    });
});

router.get('/sort-doubles-points:direction', function(req, res) {
    scrape(function(tableData) {

    });
});

router.get('/sort-doubles-points:direction', function(req, res) {
    scrape(function(tableData) {

    });
});

router.get('/sort-doubles-points:direction', function(req, res) {
    scrape(function(tableData) {

    });
});

router.get('/sort-doubles-points:direction', function(req, res) {
    scrape(function(tableData) {

    });
});


function scrape(callback) {
    var http = require('http');
    http.get({
        host: 'bonziniusa.com',
        path: '/foosball/tournament/players/rankings.html'
    }, function(response) {
        // Continuously update stream with data
        var body = '';
        response.on('data', function(d) {
            body += d;
        });
        response.on('end', function() {

            // Data reception is done, do whatever with it!
            //var parsed = JSON.parse(body);
            //console.log(body);
            function player(csvRow) {
                var x = 0;
                this.code = csvRow[x++];
                this.lastName = csvRow[x++];
                this.firstName = csvRow[x++];
                this.city = csvRow[x++];
                this.state = csvRow[x++];
                this.singlesPoints = csvRow[x++];
                this.singlesMatches = csvRow[x++];
                this.doublesPoints = csvRow[x++];
                this.doublesMatches = csvRow[x++];

            }

            var htmlparser = require("htmlparser");
            var rawHtml = body;
            var playersArray = [];
            var handler = new htmlparser.DefaultHandler(function(error, dom) {
                if (error) {

                } else {
                    var onlyRows = [];
                    var onlyCells = [];
                    var table = dom[0].children[3];
                    var tableRows = table.children[1].children;
                    for (var z = 0; z < tableRows.length; z++) {
                        if (tableRows[z].name === 'tr') {
                            onlyRows.push(tableRows[z]);
                        }
                    }

                    for (var x = 0; x < onlyRows.length; x++) {
                        var tds = onlyRows[x].children;
                        var tempArray = [];
                        for (var i = 0; i < tds.length; i++) {

                            if (tds[i].name === 'td' && tds[i].children !== undefined) {


                                tempArray.push(tds[i].children[0].data);

                            }
                        }
                        if (tempArray.length > 0) {
                            playersArray.push(new player(tempArray));
                        }



                    }
                    callback({ tableHeader: playersArray.shift(), tableData: playersArray });


                }

            });
            var parser = new htmlparser.Parser(handler);
            parser.parseComplete(rawHtml);
        });
    });
}

module.exports = router;
